## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup,eval=FALSE---------------------------------------------------------
#  ## Required libraries
#  library(netRandomForest)
#  library(randomForest)
#  library(rerf)
#  library(Matrix)
#  library(MASS)
#  library(lattice)
#  library(igraphdata)
#  library(igraph)
#  library(sand)
#  library(devtools)
#  library(dplyr)
#  library(caret)
#  library(naniar)
#  library(tidyr)
#  library(ggplot2)
#  library(reshape2)
#  library(rARPACK)
#  library(varhandle)
#  library(ROCR)
#  
#  ## Source functions
#  source("../../Plots.R")
#  source("../../extra_functions.R")
#  source("../../generate_data_SBM.R")

## ----cache=TRUE,eval=FALSE----------------------------------------------------
#  ## Generate the data set
#  set.seed(45)
#  SBM_sims_df=generate_data_SBM(q=0.4,n=100,m1=50,m2=50)
#  head(SBM_sims_df)

## ----eval=FALSE---------------------------------------------------------------
#  ## Perform data splitting
#  testing_data_ind = createDataPartition(SBM_sims_df$response, p = .25, list = FALSE) %>% as.vector(.)
#  training_data_ind = (1:nrow(SBM_sims_df))[-testing_data_ind]
#  
#  ## Create a matrix to store the results of the simulation to later be converted to a dataframe object
#  ### col 1 = "Sim", col 2 = "q value" (0.2-0.5, inclusive), col 3 = "RF" (Standard RF model), col 4 = "NRF1" (RF model with clustering outside the trees), col 5 = "NRF2" (RF model with clustering within each tree), col 6 = "RerF" (Randomer Forest model)
#  
#  rf_methods_all=matrix(ncol=6,nrow=5*4) # 5 reps * 4 different q values
#  
#  ## Define constant variables outside of all loops
#  num_clusters=3
#  index=0 # Initializing row index for the rf_methods_all table
#  
#  ## Obtain the accuracies for a given p1 value, then populate the sims table
#  for(j in c(1:5)){ # 5 replications
#  
#    q_vals=c(.2,.3,.4,.5)
#  
#    for(i in 1:length(q_vals)){
#  
#      index=index+1
#  
#      rf_methods_all[index,1]=j # Store sim number
#  
#      q=q_vals[i]
#      rf_methods_all[index,2]=q
#  
#      ## Randomly generate a dataset
#      set.seed(j)
#      SBM_sims_df=generate_data_SBM(q=q,n=100,m1=50,m2=50)
#  
#      ## Method 1: Standard random forest
#      ## Cross validation not necessary! But still need to split into testing and training (using
#      ## only first fold)
#  
#      training_data=SBM_sims_df[training_data_ind,]
#      testing_data=SBM_sims_df[testing_data_ind,]
#  
#      ## Train classifier on training_data_list[[1]]
#      set.seed(45)
#      rf_mod1 <- randomForest(x=training_data[,c(3:ncol(training_data))],
#                         y=factor(training_data[,2]),
#                         ntree=10,
#                         importance=TRUE)
#  
#      ## Test classifier on testing_data_list[[1]]
#      test=predict(rf_mod1,newdata=testing_data[,c(2:ncol(testing_data))],type='response')
#  
#      ## Store results
#      rf_methods_all[index,3]=1-mean(test != testing_data$response) # Store classification accuracy of the standard RF method
#  
#  
#      ## Method 2: Custom random forest method with cluster outside the trees
#  
#      ## Train classifier on training_data_list[[1]]
#      rf_mod2=rf_training(B=10,n=80,X_training=training_data[,c(3:ncol(training_data))],Y_training=training_data[,2],num_clusters=num_clusters,prop_vert=.8,method="anova")
#  
#      ## Test classifier on testing_data_list[[1]]
#      test=rf_testing_pred(X_testing=testing_data[,c(3:ncol(testing_data))],Y_testing=testing_data[,2],rf_training=rf_mod2,num_clusters=num_clusters,method="anova")
#  
#      ## Store results
#      rf_methods_all[index,4]=1-mean(test != testing_data$response)
#  
#  
#      ## Method 3: Custom random forest method with cluster within the trees
#  
#      ## Train classifier on training_data_list[[1]]
#      rf_mod3=rf_training2(B=10,n=80,X_training=training_data[,c(3:ncol(training_data))],Y_training=training_data[,2],num_clusters=num_clusters,prop_vert=.8,method="anova")
#  
#      ## Test classifier on testing_data_list[[1]]
#      test=rf_testing_pred2(X_testing=testing_data[,c(3:ncol(testing_data))],Y_testing=testing_data[,2],rf_training=rf_mod3,num_clusters=num_clusters,method="anova")
#  
#      ## Store results
#      rf_methods_all[index,5]=1-mean(test != testing_data$response)
#  
#  
#      ## Method 4: SPORF
#      rf_mod4 <- RerF(X=training_data[,c(3:ncol(training_data))],
#                      Y=factor(training_data[,2]),
#                      trees=10,
#                      num.cores = 1L,
#                      seed = 45)
#      test <- Predict(testing_data[,c(2:ncol(testing_data))], rf_mod4, num.cores = 1L, Xtrain =
#                      training_data[,c(3:ncol(training_data))])
#      rf_methods_all[index,6] <- 1-mean(test != testing_data$response)
#    }
#  }
#  
#  ## Convert to a dataframe object, add column names, and display the results (should only have the first 5 rows populated so far since I only did one sim)
#  rf_methods_all=data.frame(rf_methods_all)
#  colnames(rf_methods_all)=c("Sim","q_value","RF","NRF1","NRF2","RerF")
#  
#  ## Convert from wide to long format
#  # names(results_melted) <- c("p1_p2_AbsDiff", "RF_Method", "Classification_Acc")
#  # rf_methods_all2 = data_summary(results_melted,"Mean_Acc",c("p1_p2_AbsDiff","RF_Method"))
#  # rf_methods_all2
#  
#  ## Note: The first method doesn't seem to work, so I will try the same thing using dpylr functions
#  # detach(package:plyr)
#  rf_methods_allw=rf_methods_all
#  rf_methods_allw=rf_methods_allw %>%
#                    group_by(q_value) %>%
#                    summarise(RF.Mean = mean(RF),RF.SD = sd(RF), NRF1.Mean = mean(NRF1),NRF1.SD =
#                              sd(NRF1), NRF2.Mean = mean(NRF2),NRF2.SD = sd(NRF2),
#                              SPORF.Mean = mean(SPORF),SPORF.SD = sd(SPORF),SVM.Mean =
#                              mean(SPORF),SVM.SD = sd(SPORF))
#  
#  rf_methods_alll=rf_methods_allw %>%
#                    gather(v, value, RF.Mean:SVM.SD) %>%
#                    separate(v, c("RF_Method", "col")) %>%
#                    arrange(q_value) %>%
#                    spread(col, value)
#  
#  ## Displaying the results
#  rf_methods_alll

